from f5_ai_gateway_sdk.request_input import MessageRole
from f5_ai_gateway_sdk.response_output import ResponseOutput


def test_json_object_hook_parses():
    response_json = '{"choices": [{"message": {"content": "Everybody loves cats because cats are cute and cuddly. But what if cats were lions? What would the world be like if cats were lions?", "role":"assistant"}}]}'

    parsed_response = ResponseOutput.model_validate_json(response_json)

    assert isinstance(parsed_response, ResponseOutput)
    assert len(parsed_response.choices) == 1
    assert (
        parsed_response.choices[0].message.content
        == "Everybody loves cats because cats are cute and cuddly. But what if cats were lions? What would the world be like if cats were lions?"
    )
    assert parsed_response.choices[0].message.role == MessageRole.ASSISTANT
