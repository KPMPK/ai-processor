from unittest import TestCase

from f5_ai_gateway_sdk.sysinfo import SysInfo


class SysInfoTest(TestCase):
    def test_init(self):
        sys_info = SysInfo(service_name="service_name", service_version=None)
        self.assertIsInstance(sys_info, SysInfo)

    def can_assign_values_via_dict(self):
        sys_info = SysInfo(service_name="service_name", service_version=None)
        sys_info["service_name"] = "service_name"
        sys_info["service_version"] = "service_version"
        self.assertEqual(sys_info["service_name"], "service_name")
        self.assertEqual(sys_info["service_version"], "service_version")
