"""SDK Processor that is dynamically judgy based upon the request and is self-aware for reporting."""

import typing

from pydantic import Field
from starlette.requests import Request

from f5_ai_gateway_sdk import errors
from f5_ai_gateway_sdk.request_input import RequestInput
from f5_ai_gateway_sdk.response_output import ResponseOutput
from f5_ai_gateway_sdk.parameters import Parameters
from f5_ai_gateway_sdk.processor import Processor
from f5_ai_gateway_sdk.result import Result
from f5_ai_gateway_sdk.signature import BOTH_SIGNATURE
from f5_ai_gateway_sdk.type_hints import Metadata


class JudgyParameters(Parameters):
    """Held mechanics around controlling Judgy, the Processor.

    Holds useful requirements around how Judgy, the Processor, will behave during runtime as it governs itself within
    its sphere of influence.
    """

    # Controls:
    # ToDo: update these controls as the MultipartResponse changes this
    # whether to reject all that was given
    reject: typing.Optional[bool] = Field(default=None)
    # what to reject with
    reject_reason: typing.Optional[dict[str, str]] = Field(default=None)
    # whether to flag the response as modified
    modified: typing.Optional[bool] = Field(default=None)
    # what is modified
    modified_result: typing.Optional[dict[str, str]] = Field(default=None)
    # why modification took place
    modified_reason: typing.Optional[str] = Field(default=None)
    # raise if raising == prompt and they're of the same type
    raising: typing.Optional[str] = None
    # add a set type which cannot be represented in JSON to verify pydantic conversion
    set_data: set[str] = Field(default_factory=set)

    def __post_init__(self):
        """Verify that each of the types are as expected.

        Verifies, as a Parameters class could use built-in errors for Processor, the contents of the dataclass by
        types as expected by definition.
        """
        if any(
            (
                illegal_types := {
                    attr: getattr(self, attr)
                    for attr in ["reject", "modified"]
                    if not isinstance(getattr(self, attr), (bool, type(None)))
                }
            )
        ):
            raise TypeError(f"illegal non-boolean values in {illegal_types}")
        if any(
            (
                illegal_types := {
                    attr: getattr(self, attr)
                    for attr in ["reject_reason", "modified_result"]
                    if not isinstance(getattr(self, attr), (dict, type(None)))
                }
            )
        ):
            raise TypeError(f"illegal non-dict values in {illegal_types}")
        if any(
            (
                illegal_types := {
                    attr: getattr(self, attr)
                    for attr in ["modified_reason"]
                    if not isinstance(getattr(self, attr), (str, type(None)))
                }
            )
        ):
            raise TypeError(f"illegal non-str values in {illegal_types}")


class JudgyRequiredParameters(JudgyParameters):
    required_message: str


class Judgy(Processor):
    """Complete processor that behaves differently depending on JudgyParameters settings."""

    def __init__(self, *processor_args, **processor_kwargs):
        """Allow for exceptions to be raised from Judgy during process()."""
        self.raise_error = None
        super().__init__(signature=BOTH_SIGNATURE, *processor_args, **processor_kwargs)

    def process(
        self,
        prompt: RequestInput,
        response: ResponseOutput,
        metadata: Metadata,
        parameters: JudgyParameters,
        request: Request,
    ) -> Result:
        """Respond dynamically based upon parameters given to the object initially by the test."""
        if isinstance((raise_error := self.raise_error), Exception):
            raise raise_error
        if not isinstance((used_parameters := parameters), JudgyParameters):
            used_parameters = self.parameters
        my_response = dict(
            metadata=metadata,
            modified=used_parameters.modified or False,
            rejected=used_parameters.reject or False,
        )
        if reason := used_parameters.modified_reason:
            my_response["processor_result"] = dict(reason=reason)
        if prompt and used_parameters.modified:
            my_response["modified_prompt"] = prompt
        if response and used_parameters.modified:
            my_response["modified_response"] = response
        if (
            isinstance(prompt, type(parameters.raising))
            and prompt == parameters.raising
        ):
            raise errors.ProcessExecutionError(
                f"judgy: {prompt} matches {parameters.raising}"
            )
        return Result(**my_response)
