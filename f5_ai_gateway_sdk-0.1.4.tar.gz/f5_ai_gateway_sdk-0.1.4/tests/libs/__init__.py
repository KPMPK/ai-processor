"""Basic module abstraction for hierarchical referencing."""
