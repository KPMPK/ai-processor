## Testing Clients

Are used either because they are lightweight or because standing up a service exceeds the current possiblities of product development.

What follows are clients supported for testing purposes for the SDK.

### Starlette's `testclient`

[Described here](https://www.starlette.io/testclient/), the `testclient` from `starlette` offers some nifty mechanics to allow users to perform contract and behavioral testing without standing up a service.
