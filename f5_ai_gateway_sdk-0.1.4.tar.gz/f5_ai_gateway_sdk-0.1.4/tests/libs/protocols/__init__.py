"""Test library hierarchical referencing for different protocols."""
