import json
import unittest
from io import BytesIO

from parameterized import parameterized
import pytest

from f5_ai_gateway_sdk.request_input import RequestInput, Message
from f5_ai_gateway_sdk.multipart_fields import (
    INPUT_NAME,
    RESPONSE_NAME,
    METADATA_NAME,
)
from f5_ai_gateway_sdk.multipart_response import MultipartResponse
from f5_ai_gateway_sdk.response_output import Choice, ResponseOutput

from .multipart_decoder_helper import MultipartDecoderHelper

PROMPT_FIELD = bytes(INPUT_NAME, "us-ascii")
RESPONSE_FIELD = bytes(RESPONSE_NAME, "us-ascii")
METADATA_FIELD = bytes(METADATA_NAME, "us-ascii")


@pytest.mark.usefixtures("class_data_loader")
class MultipartResponseTest(unittest.IsolatedAsyncioTestCase):
    def test_consequence_invalid_status_code(self):
        """Verify that the status code of 4xx send to MultipartResponse raises."""
        prompt = "Are cats better than dogs?"
        metadata = {
            "user_id": "1234",
            "processor_result": {"processor": "testing"},
            "tags": {"status": ["bad status"]},
        }

        status_code = 600

        with pytest.raises(ValueError) as err:
            MultipartResponse(
                modified_prompt=prompt, metadata=metadata, status_code=status_code
            )
        self.assertIn("Invalid HTTP status code", err.value.args)

    def test_consequence_undefined_metadata(self):
        """Verify, as far as render_multipart is, that a default metadata raises."""

        prompt = "Are cats better than dogs?"

        with pytest.raises(ValueError) as err:
            # noinspection PyTypeChecker
            MultipartResponse(modified_prompt=prompt, metadata=None, status_code=200)
        self.assertIn("Metadata is required", err.value.args)

    @parameterized.expand(
        [
            (
                RequestInput(messages=[Message(content="Are cats better than dogs?")]),
                ResponseOutput(
                    choices=[Choice(message=Message(content="Yes they are"))]
                ),
                {
                    "user_id": "12345",
                    "processor_result": {"processor": "test"},
                    "tags": ["test", "canine"],
                },
            ),
            (
                RequestInput(messages=[Message(content="Are cats better than dogs?")]),
                None,
                {"user_id": "54321", "processor_result": {"processor": "test2"}},
            ),
            (
                RequestInput(messages=[Message(content="Are cats better than dogs?")]),
                None,
                {"user_id": "54321", "processor_result": {"processor": "test2"}},
            ),
            (
                RequestInput(messages=[Message(content="Are cats better than dogs?")]),
                None,
                {"processor": "test2"},
            ),
            (
                RequestInput(messages=[Message(content="Are cats better than dogs?")]),
                None,
                {},
            ),
        ]
    )
    async def test_render_multipart(self, prompt, response, metadata):
        expected_response_metadata = metadata.copy()

        multipart_response = MultipartResponse(
            modified_prompt=prompt,
            modified_response=response,
            metadata=metadata,
            status_code=200,
        )

        content = await MultipartResponseTest.buffer_response(multipart_response)
        multipart = MultipartDecoderHelper(
            content=content, content_type=multipart_response.headers["Content-Type"]
        )

        def assert_multipart_field(field_name, expected_value, content_type):
            if expected_value is None:
                self.assertNotIn(field_name, multipart)
            else:
                self.assertIn(field_name, multipart)
                multipart_field = multipart[field_name]
                expected_content_disposition = f'form-data; name="{field_name}"'
                self.assertEqual(
                    expected_content_disposition, multipart_field.content_disposition()
                )
                self.assertEqual(content_type, multipart_field.content_type())
                self.assertEqual(expected_value, multipart_field.content)

        assert_multipart_field(
            field_name=INPUT_NAME,
            expected_value=(prompt.model_dump_json() if prompt else None),
            content_type=MultipartResponse.TEXT_CONTENT_TYPE,
        )
        assert_multipart_field(
            field_name=RESPONSE_NAME,
            expected_value=(response.model_dump_json() if response else None),
            content_type=MultipartResponse.TEXT_CONTENT_TYPE,
        )
        assert_multipart_field(
            field_name=METADATA_NAME,
            expected_value=json.dumps(expected_response_metadata),
            content_type=MultipartResponse.METADATA_CONTENT_TYPE,
        )
        multipart_metadata = multipart.metadata
        response_metadata = multipart_metadata.as_json()

        self.assertEqual(expected_response_metadata, response_metadata)

    @staticmethod
    async def buffer_response(response: MultipartResponse) -> bytes:
        buffer = BytesIO()
        async for chunk in response.body_iterator:
            buffer.write(chunk)

        return buffer.getvalue()
