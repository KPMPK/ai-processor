import json
from typing import Iterable, Optional

from email.message import Message

from requests.structures import CaseInsensitiveDict
from requests_toolbelt import MultipartDecoder
from requests_toolbelt.multipart.decoder import BodyPart

from f5_ai_gateway_sdk.multipart_fields import (
    HEADER_ENCODING,
    INPUT_NAME,
    INPUT_PARAMETERS_NAME,
    RESPONSE_NAME,
    RESPONSE_PARAMETERS_NAME,
    METADATA_NAME,
    DEFAULT_ENCODING,
)
from f5_ai_gateway_sdk.type_hints import JSON


class FieldValue:
    def __init__(self, part: BodyPart):
        self.encoding = part.encoding if part.encoding else DEFAULT_ENCODING
        self.content = part.content.decode(self.encoding)
        self.headers = CaseInsensitiveDict()
        for key, value in part.headers.items():
            self.headers[key.decode(HEADER_ENCODING)] = value.decode(HEADER_ENCODING)

    def get_required_header(self, header_name: str) -> str:
        header = self.headers.get(header_name)
        if not header:
            raise ValueError(f"{header_name} header is not present")
        return header

    def content_disposition(self) -> str:
        return self.get_required_header("Content-Disposition")

    def content_type(self) -> str:
        return self.get_required_header("Content-Type")

    def as_json(self) -> JSON:
        return json.loads(self.content)


class MultipartDecoderHelper(dict[str, FieldValue]):
    def __init__(self, content, content_type):
        super().__init__()
        decoder = MultipartDecoder(content, content_type)
        self.add_parts_by_name(decoder.parts)

    def add_parts_by_name(self, parts: Iterable[BodyPart]):
        for part in parts:
            content_disposition = part.headers[b"Content-Disposition"]
            if not content_disposition:
                raise ValueError("Content-Disposition header is required")
            message = Message()
            message.add_header(
                "Content-Disposition", content_disposition.decode(HEADER_ENCODING)
            )
            name = message.get_param(
                param="name", unquote=True, header="Content-Disposition"
            )
            if not name:
                raise ValueError(
                    "Content-Disposition header must have a name parameter"
                )
            self[name] = FieldValue(part)

    @property
    def prompt(self) -> Optional[FieldValue]:
        return self.get(INPUT_NAME)

    @property
    def prompt_parameters(self) -> Optional[FieldValue]:
        return self.get(INPUT_PARAMETERS_NAME)

    @property
    def response(self) -> Optional[FieldValue]:
        return self.get(RESPONSE_NAME)

    @property
    def response_parameters(self) -> Optional[FieldValue]:
        return self.get(RESPONSE_PARAMETERS_NAME)

    @property
    def metadata(self) -> Optional[FieldValue]:
        return self.get(METADATA_NAME)

    def has_prompt(self) -> bool:
        return INPUT_NAME in self

    def has_prompt_parameters(self) -> bool:
        return INPUT_PARAMETERS_NAME in self

    def has_response(self) -> bool:
        return RESPONSE_NAME in self

    def has_response_parameters(self) -> bool:
        return RESPONSE_PARAMETERS_NAME in self

    def has_metadata(self) -> bool:
        return METADATA_NAME in self
