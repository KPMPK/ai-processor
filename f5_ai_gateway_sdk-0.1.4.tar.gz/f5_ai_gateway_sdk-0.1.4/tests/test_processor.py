import json
import unittest
from io import BytesIO
from typing import Any, Iterable, Mapping, Optional, Union

import pytest
from parameterized import parameterized
from f5_ai_gateway_sdk.response_output import ResponseOutput
from f5_ai_gateway_sdk.errors import ProcessorError
from f5_ai_gateway_sdk.request_input import RequestInput, Message
from f5_ai_gateway_sdk.multipart_fields import (
    DEFAULT_ENCODING,
    INPUT_NAME,
    INPUT_PARAMETERS_NAME,
    METADATA_NAME,
    RESPONSE_NAME,
)
from f5_ai_gateway_sdk.multipart_response import MultipartResponse
from f5_ai_gateway_sdk.parameters import Parameters
from f5_ai_gateway_sdk.processor import Processor, Result, Tags
from f5_ai_gateway_sdk.signature import (
    ALL_PREDEFINED_SIGNATURES,
    BOTH_RESPONSE_PROMPT_SIGNATURE,
    BOTH_SIGNATURE,
    INPUT_ONLY_SIGNATURE,
    RESPONSE_AND_PROMPT_SIGNATURE,
    RESPONSE_ONLY_SIGNATURE,
    Signature,
)
from f5_ai_gateway_sdk.type_hints import (
    Metadata,
    StreamingPrompt,
    StreamingResponse,
)
from requests_toolbelt import MultipartEncoder
from starlette.datastructures import FormData, Headers
from starlette.requests import Request
from starlette.responses import (
    Response as HttpResponse,
)
from starlette.responses import (
    StreamingResponse as HttpStreamingResponse,
)
from starlette.status import (
    HTTP_200_OK,
    HTTP_204_NO_CONTENT,
    HTTP_400_BAD_REQUEST,
    HTTP_405_METHOD_NOT_ALLOWED,
    HTTP_415_UNSUPPORTED_MEDIA_TYPE,
    HTTP_422_UNPROCESSABLE_ENTITY,
)
from starlette.types import Receive

from .multipart_decoder_helper import MultipartDecoderHelper

FAKE_NAME = "test"
FAKE_VERSION = "1"
FAKE_NAMESPACE = "testing"
APP_DETAILS = {"version": "1.0.0"}


def fake_processor(
    result: Optional[Result] = None, a_signature: Signature = BOTH_SIGNATURE
) -> Processor:
    class FakeParameters(Parameters):
        max_flow_bits: int = 10

    class FakeProcessor(Processor):
        def __init__(self, name: str, namespace: str, version: str):
            super().__init__(
                prompt_class=RequestInput,
                response_class=ResponseOutput,
                name=name,
                namespace=namespace,
                version=version,
                parameters_class=FakeParameters,
                signature=a_signature,
                app_details=APP_DETAILS,
            )

        def process(
            self,
            prompt: RequestInput,
            response: ResponseOutput,
            metadata: Metadata,
            parameters: FakeParameters,
            request: Request,
        ) -> Result:
            if parameters.max_flow_bits > 10:
                processor_result = {
                    "rejection_reason": "max_flow_bits exceeds threshold"
                }

                return Result(
                    modified_prompt=None,
                    modified_response=response,
                    metadata=metadata,
                    rejected=True,
                    processor_result=processor_result,
                )
            else:
                return result

    return FakeProcessor(FAKE_NAME, FAKE_NAMESPACE, FAKE_VERSION)


class MinimalFakeProcessor(Processor):
    def process():
        return Result()


def fake_request(
    method: str,
    headers: Optional[Mapping[str, str]] = None,
    receive: Optional[Receive] = None,
) -> Request:
    scope = {
        "type": "http",
        "path": f"/execute/{FAKE_NAMESPACE}/{FAKE_NAME.lower()}",
        "method": method,
        "path_params": {"command": "execute"},
    }
    if receive is None:
        request = Request(scope=scope)
    else:
        request = Request(scope=scope, receive=receive)

    request._headers = Headers(headers)

    return request


def fake_multipart_request(
    prompt: Union[RequestInput, StreamingPrompt] = None,
    response: Union[ResponseOutput, StreamingResponse] = None,
    metadata: Optional[Metadata] = None,
    parameters: Optional[Mapping[str, Any]] = None,
    with_filenames: Optional[bool] = False,
) -> Request:
    boundary = "boundary"
    encoding = "utf-8"

    fields = {}
    if metadata:
        metadata_json = json.dumps(metadata)
        filename = "metadata.json" if with_filenames else None
        fields[METADATA_NAME] = (filename, metadata_json, "application/json")
    if prompt:
        filename = "prompt.txt" if with_filenames else None
        fields[INPUT_NAME] = (filename, prompt, f"text/plain;charset={encoding}")
    if response:
        filename = "response.txt" if with_filenames else None
        fields[RESPONSE_NAME] = (filename, response, f"text/plain;charset={encoding}")
    if parameters:
        parameters_json = json.dumps(parameters)
        filename = "parameters.json" if with_filenames else None
        fields[INPUT_PARAMETERS_NAME] = (filename, parameters_json, "application/json")

    multipart_data = MultipartEncoder(
        fields=fields, encoding=encoding, boundary=boundary
    )

    async def receive():
        return {"type": "http.request", "body": multipart_data.to_string()}

    return fake_request(
        method="POST",
        headers={"content-type": f"multipart/form-data;boundary={boundary}"},
        receive=receive,
    )


FAKE_TAGS = Tags({"test1": ["a", "b"]})


# noinspection PyTestUnpassedFixture
@pytest.mark.usefixtures("class_data_loader")
class ProcessorTest(unittest.IsolatedAsyncioTestCase):
    maxDiff = None

    async def test_handle_head_request(self):
        request = fake_request("HEAD")
        processor = fake_processor()

        response = await processor.handle_request(request)

        self.assertStatusCodeEqual(response, HTTP_200_OK)

    async def test_handle_unsupported_method(self):
        unsupported_methods = [
            "GET",
            "PUT",
            "DELETE",
            "PATCH",
            "OPTIONS",
            "TRACE",
            "CONNECT",
            "UNKNOWN",
        ]
        processor = fake_processor()
        for method in unsupported_methods:
            request = fake_request(method)

            response = await processor.handle_request(request)

            self.assertStatusCodeEqual(response, HTTP_405_METHOD_NOT_ALLOWED)
            body = json.loads(response.body)
            self.assertEqual("Only POST requests are supported", body.get("message"))

    async def test_no_headers_set(self):
        request = fake_request("POST")
        processor = fake_processor()

        response = await processor.handle_request(request)

        self.assertStatusCodeEqual(response, HTTP_415_UNSUPPORTED_MEDIA_TYPE)
        self.assertEqual(response.body, b'{"detail": "Content-Type header missing"}')

    async def test_empty_content_type(self):
        request = fake_request(method="POST", headers={"content-type": ""})
        processor = fake_processor()

        response = await processor.handle_request(request)

        self.assertStatusCodeEqual(response, HTTP_415_UNSUPPORTED_MEDIA_TYPE)
        self.assertEqual(b'{"detail": "Content-Type header is empty"}', response.body)

    async def test_incorrect_content_type(self):
        request = fake_request(
            method="POST", headers={"content-type": "application/json"}
        )
        processor = fake_processor()

        response = await processor.handle_request(request)

        self.assertStatusCodeEqual(response, HTTP_415_UNSUPPORTED_MEDIA_TYPE)
        self.assertEqual(
            b'{"detail": "Content-Type header mismatch - expecting: multipart/form-data"}',
            response.body,
        )

    async def test_content_type_with_no_boundary(self):
        request = fake_request(
            method="POST", headers={"content-type": "multipart/form-data"}
        )
        processor = fake_processor()

        response = await processor.handle_request(request)

        self.assertStatusCodeEqual(response, HTTP_415_UNSUPPORTED_MEDIA_TYPE)
        self.assertEqual(
            b'{"detail": "Content-Type header missing boundary"}', response.body
        )

    async def test_handle_missing_parameters_metadata_and_body(self):
        async def receive():
            return {"type": "http.request"}

        request = fake_request(
            method="POST",
            headers={"content-type": "multipart/form-data;boundary=12345678"},
            receive=receive,
        )
        processor = fake_processor()

        response = await processor.handle_request(request)

        self.assertStatusCodeEqual(response, HTTP_400_BAD_REQUEST)
        self.assertEqual(b'{"detail": "metadata part is missing"}', response.body)

    async def test_handle_missing_prompt_and_response(self):
        metadata = {"key": "value"}
        request = fake_multipart_request(metadata=metadata)
        processor = fake_processor()

        response = await processor.handle_request(request)

        self.assertStatusCodeEqual(response, HTTP_400_BAD_REQUEST)
        self.assertEqual(
            b'{"detail": "input.messages (prompt) and response.choices (response) fields are missing'
            b' - at least one is required"}',
            response.body,
            "expected error message not found",
        )

    async def test_handle_malformed_metadata(self):
        body = (
            self.data_loader("malformed_metadata_body.txt")
            .replace("\n", "\r\n")
            .replace('name="body"', f'name="{INPUT_NAME}"')
        )

        async def receive():
            return {"type": "http.request", "body": body.encode()}

        request = fake_request(
            method="POST",
            headers={"content-type": "multipart/form-data;boundary=boundary"},
            receive=receive,
        )
        processor = fake_processor(a_signature=INPUT_ONLY_SIGNATURE)

        response = await processor.handle_request(request)

        self.assertStatusCodeEqual(response, HTTP_400_BAD_REQUEST)

        expected_error_msg = (
            "Unable to parse JSON field [metadata]: Unterminated string starting at: "
            + """line 1 column 3 (char 2)"""
        )
        expected_detail = '{"detail": "' + expected_error_msg + '"}'
        actual_detail = response.body.decode(DEFAULT_ENCODING)
        self.assertEqual(expected_detail, actual_detail, "expected error message")

    async def test_handle_valid_prompt_with_none_processor_result(self):
        prompt = json.dumps({"messages": [{"content": "Are cats better than dogs?"}]})
        metadata = {"key": "value"}
        request = fake_multipart_request(prompt=prompt, metadata=metadata)
        result = Result(
            modified_prompt=prompt, metadata=metadata, processor_result=None
        )
        processor = fake_processor(result=result)

        response = await processor.handle_request(request)

        self.assertStatusCodeEqual(response, HTTP_204_NO_CONTENT)
        self.assertEqual(b"", response.body, "expected empty body")

    async def test_handle_valid_prompt_with_tags_processor_result(self):
        prompt = json.dumps({"messages": [{"content": "Are cats better than dogs?"}]})
        metadata = {"key": "value"}
        request = fake_multipart_request(prompt=prompt, metadata=metadata)
        result = Result(
            metadata=metadata,
            processor_result=None,
            tags=FAKE_TAGS,
        )
        processor = fake_processor(result=result)

        response = await processor.handle_request(request)

        self.assertStatusCodeEqual(response, HTTP_200_OK)
        content = await self.buffer_response(response)
        multipart = MultipartDecoderHelper(
            content=content, content_type=response.headers["Content-Type"]
        )
        multipart_metadata = multipart.metadata

        self.assertIn("test1", multipart_metadata.content, "expected tags in response")

    async def test_handle_valid_prompt_with_empty_processor_result(self):
        prompt = json.dumps({"messages": [{"content": "Are cats better than dogs?"}]})
        metadata = {"key": "value"}
        request = fake_multipart_request(prompt=prompt, metadata=metadata)
        result = Result(
            modified_prompt=prompt, metadata=metadata, processor_result=None
        )
        processor = fake_processor(result=result)

        response = await processor.handle_request(request)

        self.assertStatusCodeEqual(response, HTTP_204_NO_CONTENT)
        self.assertEqual(b"", response.body, "expected empty body")

    async def test_handle_valid_prompt_with_processor_result(self):
        prompt = json.dumps({"messages": [{"content": "Are cats better than dogs?"}]})
        metadata = {"key": "value"}
        request = fake_multipart_request(prompt=prompt, metadata=metadata)
        result = Result(
            metadata=metadata, processor_result={"unit_test": True}, tags=FAKE_TAGS
        )
        processor = fake_processor(result=result)

        response = await processor.handle_request(request)

        self.assertStatusCodeEqual(response, HTTP_200_OK)

        content = await self.buffer_response(response)
        multipart = MultipartDecoderHelper(
            content=content, content_type=response.headers["Content-Type"]
        )
        self.assertFalse(
            multipart.has_prompt(),
            "prompt should not be in the response because it was not modified",
        )

        multipart_metadata = multipart.metadata
        self.assertEqual(
            MultipartResponse.METADATA_CONTENT_TYPE, multipart_metadata.content_type()
        )
        response_metadata = multipart_metadata.as_json()

        expected_response_metadata = self.data_loader(
            "multipart_response_metadata.json"
        )
        expected_response_metadata.update(
            dict(
                app_details=APP_DETAILS,
                processor_id=processor.id(),
                processor_version=processor.version,
            )
        )

        self.assertDictEqual(expected_response_metadata, response_metadata)

    async def test_handle_rejected_prompt(self):
        prompt = json.dumps({"messages": [{"content": "Are cats better than dogs?"}]})
        metadata = {"key": "value"}
        request = fake_multipart_request(prompt=prompt, metadata=metadata)
        result = Result(
            metadata=metadata,
            processor_result={"unit_test": True},
            tags=FAKE_TAGS,
            rejected=True,
        )
        processor = fake_processor(result=result)

        response = await processor.handle_request(request)

        self.assertStatusCodeEqual(response, HTTP_422_UNPROCESSABLE_ENTITY)

        content = await self.buffer_response(response)
        multipart = MultipartDecoderHelper(
            content=content, content_type=response.headers["Content-Type"]
        )

        self.assertFalse(
            multipart.has_prompt(), "the rejected prompt should not be in the response"
        )

        multipart_metadata = multipart.metadata
        self.assertEqual(
            MultipartResponse.METADATA_CONTENT_TYPE, multipart_metadata.content_type()
        )
        response_metadata = multipart_metadata.as_json()

        expected_response_metadata = self.data_loader(
            "multipart_response_metadata.json"
        )
        expected_response_metadata.update(
            dict(
                app_details=APP_DETAILS,
                processor_id=processor.id(),
                processor_version=processor.version,
            )
        )

        self.assertDictEqual(expected_response_metadata, response_metadata)

    async def test_handle_modified_prompt(self):
        prompt = json.dumps({"messages": [{"content": "Are cats better than dogs?"}]})
        metadata = {"key": "value"}
        request = fake_multipart_request(prompt=prompt, metadata=metadata)
        result = Result(
            modified_prompt=RequestInput(
                messages=[Message(content="Are cats better than dogs?")]
            ),
            metadata=metadata,
            processor_result={"unit_test": "true"},
            tags=FAKE_TAGS,
            rejected=False,
            modified=True,
        )
        processor = fake_processor(result=result)

        response = await processor.handle_request(request)

        self.assertStatusCodeEqual(response, HTTP_200_OK)

        content = await self.buffer_response(response)
        multipart = MultipartDecoderHelper(
            content=content, content_type=response.headers["Content-Type"]
        )

        self.assertTrue(
            multipart.has_prompt(),
            "the rewritten/modified prompt should always be in the response",
        )

        multipart_prompt = multipart.prompt

        self.assertEqual(
            MultipartResponse.TEXT_CONTENT_TYPE, multipart_prompt.content_type()
        )
        parsed_multipart_content = RequestInput.model_validate_json(
            multipart_prompt.content
        )
        self.assertEqual(
            result.prompt,
            parsed_multipart_content,
        )

        multipart_metadata = multipart.metadata
        self.assertEqual(
            MultipartResponse.METADATA_CONTENT_TYPE, multipart_metadata.content_type()
        )
        response_metadata = multipart_metadata.as_json()

        expected_response_metadata = self.data_loader(
            "multipart_response_metadata.json"
        )
        expected_response_metadata.update(
            dict(
                app_details=APP_DETAILS,
                processor_id=processor.id(),
                processor_version=processor.version,
            )
        )

        self.assertEqual(
            multipart_metadata.headers["Content-Disposition"],
            f'form-data; name="{METADATA_NAME}"',
        )
        self.assertEqual(
            multipart_metadata.headers["Content-Type"],
            MultipartResponse.METADATA_CONTENT_TYPE,
        )

        response_metadata = json.loads(multipart_metadata.content)

        expected_response_metadata = self.data_loader(
            "multipart_response_metadata.json"
        )
        expected_response_metadata.update(
            dict(
                app_details=APP_DETAILS,
                processor_id=processor.id(),
                processor_version=processor.version,
            )
        )
        expected_response_metadata["processor_result"]["unit_test"] = "true"

        self.assertDictEqual(expected_response_metadata, response_metadata)

    async def test_handle_parameter_conditional(self):
        prompt = json.dumps({"messages": [{"content": "Are cats better than dogs?"}]})
        metadata = {"key": "value"}
        parameters = {"max_flow_bits": 99}
        request = fake_multipart_request(
            prompt=prompt, metadata=metadata, parameters=parameters
        )
        result = Result(
            modified_prompt="Are dogs better than cats?",
            metadata=metadata,
            processor_result={"unit_test": "true"},
            rejected=False,
            modified=True,
        )
        processor = fake_processor(result=result)

        response = await processor.handle_request(request)
        self.assertStatusCodeEqual(response, HTTP_422_UNPROCESSABLE_ENTITY)

        content = await self.buffer_response(response)
        multipart = MultipartDecoderHelper(
            content=content, content_type=response.headers["Content-Type"]
        )

        self.assertFalse(
            multipart.prompt,
            "the rewritten/modified prompt should not be in the response",
        )

        multipart_metadata = multipart.metadata
        self.assertEqual(
            MultipartResponse.METADATA_CONTENT_TYPE, multipart_metadata.content_type()
        )
        response_metadata = multipart_metadata.as_json()

        expected_response_metadata = self.data_loader(
            "multipart_response_metadata_processor_rejected.yaml"
        )
        expected_response_metadata.update(
            dict(
                app_details=APP_DETAILS,
                processor_id=processor.id(),
                processor_version=processor.version,
            )
        )
        expected_response_metadata["processor_result"]["rejection_reason"] = (
            "max_flow_bits exceeds threshold"
        )

        self.assertDictEqual(expected_response_metadata, response_metadata)

    async def test_prompt_send_with_file_header(self):
        prompt = json.dumps({"messages": [{"content": "Are cats better than dogs?"}]})
        metadata = {"key": "value"}
        request = fake_multipart_request(
            prompt=prompt, metadata=metadata, with_filenames=True
        )
        result = Result(
            modified_prompt=prompt, metadata=metadata, processor_result=None
        )
        processor = fake_processor(result=result)

        response = await processor.handle_request(request)

        self.assertStatusCodeEqual(response, HTTP_204_NO_CONTENT)
        self.assertEqual(b"", response.body, "expected empty body")

    def test_to_dict(self):
        processor = fake_processor()
        expected = self.data_loader("processor_as_dict.yaml")
        expected.update(
            dict(
                path=f"/execute/{expected['namespace']}/{expected['name']}",
                signature_path=f"/signature/{expected['namespace']}/{expected['name']}",
            )
        )
        expected["methods"] = ["GET", "HEAD", "POST"]
        actual = processor.to_dict()
        self.assertDictEqual(
            expected,
            actual,
            "processor conversion to dict did not match expected result",
        )

    def test_name_whitespace_error(self):
        """Verify that a ValueError is issued when Processor is created with a name that contains whitespace."""
        expected_message = "Processor name cannot contain whitespace"
        with pytest.raises(ValueError) as err:
            MinimalFakeProcessor("foo bar", "", "", BOTH_SIGNATURE)
        self.assertIn(expected_message, err.value.args, str(err.value.args))

    def test_version_whitespace_error(self):
        """Verify that a ValueError is issued when Processor is created with a version that contains whitespace."""
        expected_message = "Processor version cannot contain whitespace"
        with pytest.raises(ValueError) as err:
            MinimalFakeProcessor("foo_bar", "1 1", "namespace", BOTH_SIGNATURE)
        self.assertIn(expected_message, err.value.args, str(err.value.args))

    def test_processor_neq_other_type(self):
        """Verify that a False is issued when a processor is compared to a different type."""

        class Foo:
            pass

        processor = MinimalFakeProcessor("foo_bar", "namespace", "1.1", BOTH_SIGNATURE)
        self.assertNotEqual(processor, Foo())

    def test_processor_eq_processor(self):
        """Verify two processors created the same are equal."""
        name = "foo_bar"
        version = "1.1"
        namespace = "namespace"
        processor1 = MinimalFakeProcessor(name, version, namespace, BOTH_SIGNATURE)
        processor2 = MinimalFakeProcessor(name, version, namespace, BOTH_SIGNATURE)
        self.assertEqual(processor1, processor2)

    @parameterized.expand(
        [
            (
                [METADATA_NAME, INPUT_NAME],
                [INPUT_ONLY_SIGNATURE, BOTH_SIGNATURE, BOTH_RESPONSE_PROMPT_SIGNATURE],
            ),
            ([METADATA_NAME, RESPONSE_NAME], [RESPONSE_ONLY_SIGNATURE, BOTH_SIGNATURE]),
            (
                [METADATA_NAME, RESPONSE_NAME, INPUT_NAME],
                [RESPONSE_AND_PROMPT_SIGNATURE, BOTH_RESPONSE_PROMPT_SIGNATURE],
            ),
        ]
    )
    def test_multipart_field_validation_valid(
        self, signature_fields: Iterable[str], signatures: Iterable[Signature]
    ):
        """Verify that the multipart field validation passes when all required fields are present."""
        for signature in signatures:
            processor = fake_processor(a_signature=signature)
            fields: list[tuple[str, str]] = list(
                map(lambda s: (s, ""), signature_fields)
            )
            # noinspection PyTypeChecker
            form_data = FormData(fields)
            self.assertIsNone(processor._validate_and_find_parameters_name(form_data))

    @parameterized.expand(
        [
            ([], ALL_PREDEFINED_SIGNATURES),
            ([METADATA_NAME], ALL_PREDEFINED_SIGNATURES),
            (
                [METADATA_NAME, INPUT_NAME],
                [RESPONSE_ONLY_SIGNATURE, RESPONSE_AND_PROMPT_SIGNATURE],
            ),
            (
                [METADATA_NAME, RESPONSE_NAME],
                [INPUT_ONLY_SIGNATURE, RESPONSE_AND_PROMPT_SIGNATURE],
            ),
            ([METADATA_NAME, "unknown field"], ALL_PREDEFINED_SIGNATURES),
        ]
    )
    def test_multipart_field_validation_invalid(
        self, signature_fields: Iterable[str], signatures: Iterable[Signature]
    ):
        """Verify that the multipart field validation fails when a required field is missing or wrongly assigned."""
        for signature in signatures:
            processor = fake_processor(a_signature=signature)
            fields: list[tuple[str, str]] = list(
                map(lambda s: (s, ""), signature_fields)
            )
            # noinspection PyTypeChecker
            form_data = FormData(fields)
            error_found = False
            try:
                processor._validate_and_find_parameters_name(form_data)
            except ProcessorError:
                error_found = True

            self.assertTrue(
                error_found,
                f"ProcessorError was not raised for fields: {signature_fields} "
                f"and signature: {signature}",
            )

    def test_no_subclass(self):
        expected_message = (
            "Can't instantiate abstract class Processor with abstract method process"
        )
        with pytest.raises(TypeError) as err:
            Processor("attempt-direct-processor-use", "v1", "test")
        self.assertIn(expected_message, err.value.args, str(err.value.args))

    # HELPER METHODS #

    async def buffer_response(self, response: HttpResponse) -> bytes:
        self.assertIsInstance(response, MultipartResponse)
        multipart_response: MultipartResponse = response

        buffer = BytesIO()
        async for chunk in multipart_response.body_iterator:
            buffer.write(chunk)

        return buffer.getvalue()

    def assertStatusCodeEqual(self, response: HttpResponse, status_code: int):
        if not response:
            self.fail("Response is None")

        self.assertIsInstance(
            response, HttpResponse, f"Expected HttpResponse, got {type(response)}"
        )

        if response.status_code != status_code:
            if not hasattr(response, "body") or isinstance(
                response.body, HttpStreamingResponse
            ):
                self.fail(
                    f"Expected status code {status_code}, got {response.status_code}"
                )
            else:
                self.fail(
                    f"Expected status code {status_code}, got {response.status_code}. "
                    f"Server response: \n{response.body}"
                )
