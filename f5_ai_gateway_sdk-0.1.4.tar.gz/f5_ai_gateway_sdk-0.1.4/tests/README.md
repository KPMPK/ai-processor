### Testing

Follows the `pytest` format with the flexibility of adopting `unittest.TestCase` as deemed needed for the flexibility of moving forward quickly.

### Executing Tests Locally

_Prerequisites:_
```bash
pdm venv create 3.11
pdm install
```

_Run tests:_
```bash
make test
```

_Clear PDM virtual env and any built test containers_
```bash
make clean
```

### Executing Tests In Docker

```bash
make test.container
```

This will build a test image with required python dependencies and mount the [src](../src) and [tests](../tests) directories. This is by product version, so each push to `main` that increments the version will result in a new local docker image.

To clear the current docker image installed, then please execute:
```bash
make clean.container
```
Previous versions may be purged using `make clean` as well with the `VERSION` overwritten; thus:
```bash
make clean.container VERSION="0.0.22"
```
Will purge the version `0.0.22`'s image.


### Nomenclature

Different forms of tests for the layers of the "test onion" or "testing pyramid" concentrate on assuring specific things either functionally, at a contract level, non-functionally, etc, and most tests at this level will be functional, but largely at the SDK-component level.

#### Terms

*unit test* is often numerous and functionally provides both happy path and negative path functionality assurance to the developer that things, as they iterate, still "work"

*white box* is the portion of a test that is fully understood and is dissected by the test through mocks within code and _should only occur in unit testing_ owned primarily by developers that implies intimate knowledge of the code

*black box* is the portion of the product that is "hands off" to the test whose functionality or behavior is under test that cannot be viewed or dissected by the test but whose inputs and outputs may be tailored for expected behavior that may not indicate any knowledge of the code

*grey box* is the portion of the *subsystem* or portion of the *component* speaking to the/a component under test whose initial interaction might be mocked, injected, or substituted, but later interactions might be valid behavioral responses that are checked that implies some knowledge of the code

*contract* test deals with testing that assures that one side of the communication comes back as anticipated.  May cover some functionality requirements, but largely assures that the contract (agreed upon API interaction) is satisfied between two components; may also involve any number of mocked out "services" using [pact-python](https://github.com/pact-foundation/pact-python) as necessary; should not treat anything as "eventually consistent" as its the raw responses that are tested for change-in-contract detection.  This implies some level of *grey box* level of knowledge to the component whose side is under test.

*component* is a single runtime awarded a single process; thus a *contract* test should mock out its database backend as that is a separate *component* on a data service.  Speaks to a side of an interaction that requires outside protocols and may include (up to and including) API interactions with databases (database is mocked), outside services that a client speaks to (service is mocked), outside streams that a subscriber or publisher speak to across a bus, etc, but does not include the protocol itself to speak to them because this is included in the test (other side is mocked).

*subsystem* test deals with a group of components that are stood up and should be lenient with "eventually consistent" as the premise or philosophy and then ratcheted down by reducing timeouts while waiting or in looped waits between states or responses between different components.  This concentrates on "enboxed" components.

*sequence* test speaks to a "happy path" behavioral test that concentrates on validating the product behavior

*consequence* test speaks to an "unhappy path" behavioral test that concentrates on validating what the product does with a "naughty" or "ignorant" user or incorrect input

*black sheep scenario* speaks to a highly predictable, but often overlooked behavior that is easily testable at some layer of testing

#### `data_loader`s `unittest.TestCase` Support

Comes with the simple addition of the `class` decorator of:
```python
import unittest

import pytest


@pytest.mark.usefixtures("class_data_loader")
class TestFoo(unittest.TestCase):
    def test_foo(self, ...):
        test_data = self.data_loader(...)
```

These are static files that are decoded from either `yaml`, `json`, or plain text based upon extensions, and loaded into the return value.
