from f5_ai_gateway_sdk.request_input import RequestInput, MessageRole


def test_json_object_hook_parses():
    input_json = '{"messages": [{"content": "Everybody loves cats because cats are cute and cuddly. But what if cats were lions? What would the world be like if cats were lions?"}]}'

    parsed_input = RequestInput.model_validate_json(input_json)

    assert isinstance(parsed_input, RequestInput)
    assert len(parsed_input.messages) == 1
    assert (
        parsed_input.messages[0].content
        == "Everybody loves cats because cats are cute and cuddly. But what if cats were lions? What would the world be like if cats were lions?"
    )
    assert parsed_input.messages[0].role == MessageRole.USER


def test_json_object_hook_allows_role():
    input_json = '{"messages": [{"content": "Everybody loves cats because cats are cute and cuddly. But what if cats were lions? What would the world be like if cats were lions?", "role":"system"}]}'

    parsed_input = RequestInput.model_validate_json(input_json)

    assert isinstance(parsed_input, RequestInput)
    assert len(parsed_input.messages) == 1

    assert parsed_input.messages[0].role == MessageRole.SYSTEM
