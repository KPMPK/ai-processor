"""Verify certain contractual exchanges against a stood up processor."""

from starlette import status as http_status_codes
from starlette.routing import Mount

from f5_ai_gateway_sdk.processor_routes import ProcessorRoutes
from ..libs.fakes import processors as fake_processors

EXPECTED_API_VERSIONS = 1


def test_processor_routes_simple(processor_routes_client_loader, test_logger):
    """Assure that we can have simplicity."""
    processor_routes = ProcessorRoutes([])
    # one for /api/<version> and a redirect to there from /
    assert len(processor_routes) == 2
    client = processor_routes_client_loader(processor_routes)
    assert (
        (response := client.head("/")).status_code == http_status_codes.HTTP_200_OK
    ), f"({response.status_code}) {response.url}"


def test_processor_routes_mounted_routes(processor_routes_client_loader, test_logger):
    """API version mounts are created and populated with /info"""
    processor_routes = ProcessorRoutes([])
    assert len(processor_routes) == 2
    mounts = [route for route in processor_routes if isinstance(route, Mount)]
    assert len(mounts) == EXPECTED_API_VERSIONS
    assert len(mounts[0].routes) == 1
    client = processor_routes_client_loader(processor_routes)
    assert (
        (response := client.head("/")).status_code == http_status_codes.HTTP_200_OK
    ), f"({response.status_code}) {response.url}"


def test_processor_routes_get_no_accept(processor_routes_client_loader, test_logger):
    """Assure that we can have simplicity."""
    processor_routes = ProcessorRoutes([])
    assert len(processor_routes) == 2
    client = processor_routes_client_loader(processor_routes)
    assert (
        (response := client.get("/")).status_code == http_status_codes.HTTP_200_OK
    ), f"({response.status_code}) {response.url}"
    assert (
        result := response.text
    ) == "", f"received additional text: {result}, outside of an empty GET"


def test_processor_routes_get_empty_accept(processor_routes_client_loader, test_logger):
    """Assure that we can have simplicity."""
    processor_routes = ProcessorRoutes([])
    assert len(processor_routes) == 2
    client = processor_routes_client_loader(processor_routes)
    assert (
        (response := client.get("/", headers={"Accept": ""})).status_code
        == http_status_codes.HTTP_200_OK
    ), f"({response.status_code}) {response.url}"
    assert (
        result := response.text
    ) == "", f"received additional text, {result}, outside of an empty GET"


def test_processor_routes_get_accept_json(
    data_loader, processor_routes_client_loader, test_logger
):
    """Assure that we can have simplicity for listing endpoints via json."""
    processor_routes = ProcessorRoutes([])
    expected_response = data_loader("empty_processor_routes.json")
    assert len(processor_routes) == 2
    client = processor_routes_client_loader(processor_routes)
    assert (
        (
            response := client.get("/", headers={"Accept": "application/json"})
        ).status_code
        == http_status_codes.HTTP_200_OK
    ), f"({response.status_code}) {response.url}"
    assert (
        result := response.json()
    ) == expected_response, f"simple get got {result} instead of {expected_response}"


def test_processor_routes_get_accept_html(
    data_loader, processor_routes_client_loader, test_logger
):
    """Assure that we can have simplicity for listing empty html result."""
    processor_routes = ProcessorRoutes([])
    expected_response = data_loader("empty_processor_routes.html").strip()
    assert len(processor_routes) == 2
    client = processor_routes_client_loader(processor_routes)
    assert (
        (response := client.get("/", headers={"Accept": "text/html"})).status_code
        == http_status_codes.HTTP_200_OK
    ), f"({response.status_code}) {response.url}"
    assert (
        result := response.text.strip()
    ) == expected_response, f"simple get got {result} instead of {expected_response}"


def test_processor_routes_get_accept_markdown(
    data_loader, processor_routes_client_loader, test_logger
):
    """Assure that we can have simplicity for listing empty html result."""
    processor_routes = ProcessorRoutes([])
    expected_response = data_loader("empty_processor_routes.md").strip()
    assert len(processor_routes) == 2
    client = processor_routes_client_loader(processor_routes)
    assert (
        (response := client.get("/", headers={"Accept": "text/markdown"})).status_code
        == http_status_codes.HTTP_200_OK
    ), f"({response.status_code}) {response.url}"
    assert (
        result := response.text.strip()
    ) == expected_response, f"simple get got {result} instead of {expected_response}"


def test_processor_routes_get_with_one_processor(
    data_loader, processor_routes_client_loader, test_logger
):
    """Assure that we can have one processor listed through outputs."""
    html_template = """<!DOCTYPE html><html><head><meta charset="utf-8" /><title>Processor Routes</title></head><body><ul><li><a href=
"./execute/{namespace}/{processor}">{namespace}:{processor}: /execute/{namespace}/{processor} [HEAD, POST]</a></li><ul><li>
<a href="./signature/{namespace}/{processor}">{namespace}:{processor}: /signature/{namespace}/{processor} [GET, POST]</a></li>
</ul></ul></body></html>
""".replace("\n", "")

    processor_name = "judgy"
    processor_version = "1.1"
    processor_namespace = "testing"
    expected_response = html_template.format(
        processor=processor_name,
        namespace=processor_namespace,
    ).strip()
    judgy = fake_processors.Judgy(
        processor_name,
        processor_version,
        processor_namespace,
        parameters_class=fake_processors.JudgyParameters,
    )
    processor_routes = ProcessorRoutes([judgy])
    assert len(processor_routes) == 2
    mounts = [route for route in processor_routes if isinstance(route, Mount)]
    assert len(mounts) == EXPECTED_API_VERSIONS
    assert len(mounts[0].routes) == 2
    client = processor_routes_client_loader(processor_routes)
    assert (
        (response := client.get("/", headers={"Accept": "text/html"})).status_code
        == http_status_codes.HTTP_200_OK
    ), f"({response.status_code}) {response.url}"
    assert (
        result := response.text.strip()
    ) == expected_response, f"simple get got {result} instead of {expected_response}"
