[![FOSSA Status](https://app.fossa.com/api/projects/git%2Bgithub.com%2Fdekobon%2Ff5-ai-gateway-sdk.svg?type=shield&issueType=license)](https://app.fossa.com/projects/git%2Bgithub.com%2Fdekobon%2Ff5-ai-gateway-sdk?ref=badge_shield&issueType=license)

# Python Starlette Processor SDK

This project is a Python SDK for the Starlette framework. It is designed
to be used as a base for building a Starlette application that implements
Python based Processors for the AI Gateway.

## Testing

Please look to [the instructions for running the tests locally here](./tests/README.md#executing-tests-locally).

## Formatting and Linting

This project uses [Ruff](https://docs.astral.sh/ruff/) for formatting and linting.

## Make targets

Run `make help` to see available make targets, such as `build`, `fmt`, `lint`, `test`.

## Publishing to [Artifactory](https://azr.artifactory.f5net.com/ui/repos/tree/General/f5-aigw-pypi/f5-ai-gateway-sdk)

### Pre-Release Version

1. Update [`pyproject.toml`](./pyproject.toml) with the desired non-final pre-release version (see [PyPI](https://packaging.python.org/en/latest/discussions/versioning/) docs for version details)
2. Go to `Actions` > `CI` > `Run workflow`
   1. Set `Branch` to desired branch
   2. Set `force_publish_pypi` to `true`
   3. Run

### Release Version

1. Ensure [`pyproject.toml`](./pyproject.toml) has the correct version
2. Create and push a tag matching that version
