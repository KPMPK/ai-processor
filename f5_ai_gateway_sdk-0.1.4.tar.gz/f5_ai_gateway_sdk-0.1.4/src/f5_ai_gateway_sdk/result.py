from typing import Optional

from starlette.responses import Response
from starlette.status import (
    HTTP_200_OK,
    HTTP_204_NO_CONTENT,
    HTTP_422_UNPROCESSABLE_ENTITY,
)

from f5_ai_gateway_sdk.request_input import RequestInput
from f5_ai_gateway_sdk.response_output import ResponseOutput

from .multipart_response import MultipartResponse
from .tags import Tags
from .type_hints import Metadata


class Result:
    """
    Class representing the result of processing a prompt and metadata.
    This object encodes whether the request was rejected, and whether
    the prompt/response pair should be rewritten.
    """

    def __init__(
        self,
        modified_prompt: Optional[RequestInput] = None,
        modified_response: Optional[ResponseOutput] = None,
        metadata: Optional[Metadata] = None,
        processor_result: Optional[Metadata] = None,
        tags: Optional[Tags] = None,
        rejected: bool = False,
        modified: bool = False,
    ):
        """
        :param modified_prompt: rewritten or modified prompt to be returned in the HTTP response
        :param modified_response: rewritten or modified response to be returned in the HTTP response
        :param metadata: root metadata containing pre-defined fields
        :param processor_result: free-form metadata resulting from process execution
        :param tags: used for annotating a transaction with notable properties
        :param rejected: flag indicating that the prompt/metadata submitted is unacceptable
        :param modified: flag indicating that the prompt has been modified
        """
        self.prompt = modified_prompt
        self.response = modified_response
        self.metadata = metadata if metadata else Metadata()
        self.processor_result = processor_result if processor_result else {}
        self.tags = tags if tags else Tags()
        self.rejected = rejected
        self.modified = modified

    def to_response(self) -> Response:
        """
        Converts the Result object to a Starlette Response object, with the following rules:
          If the result is rejected, a 422 status code is returned.
          If the prompt was modified, the modified prompt is sent in the body along with the metadata, and
          a 200 status code is returned.
          If the prompt was not modified and a processor result (additional metadata) is set,
          the processor result is sent in the body, and a 200 status code is returned.
          If the prompt was not modified and no processor result is set, no body is sent, and
          a 204 status code is returned.

        :return: Starlette Response object
        """

        # There is something wrong with the content submitted, so we send back metadata
        if self.rejected:
            status_code = HTTP_422_UNPROCESSABLE_ENTITY
        # Either the prompt or the response was modified, so we send back the modified
        # content and any extra data
        elif self.modified:
            status_code = HTTP_200_OK
        # Neither the prompt nor the response was not modified, but we have extra
        # information to communicate back, so we send back the metadata without the
        # body
        elif self.processor_result or self.tags:
            status_code = HTTP_200_OK
        # Everything is good and there is no extra information to communicate back
        else:
            return Response(status_code=HTTP_204_NO_CONTENT)

        # Although in our object model here processor_result is a different object, in the actual implementation
        # of the HTTP response, it is a field on the metadata response object.
        if self.processor_result:
            self.metadata["processor_result"] = self.processor_result
        # Likewise with tags
        if self.tags:
            self.metadata["tags"] = self.tags.to_response()

        return MultipartResponse(
            modified_prompt=self.prompt,
            modified_response=self.response,
            metadata=self.metadata,
            status_code=status_code,
        )


__all__ = ["Result", "Tags"]
