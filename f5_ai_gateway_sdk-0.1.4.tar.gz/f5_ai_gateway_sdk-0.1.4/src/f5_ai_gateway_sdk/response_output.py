from typing import List

from pydantic import BaseModel

from .request_input import Message


class Choice(BaseModel):
    """
    Represents a choice returned from an upstream.

    :param message: The ``Message`` object associated with the choice.
    """

    __autoclass_content__ = "class"

    message: Message


class ResponseOutput(BaseModel):
    """
    Represents a collection of ``Message`` objects.

    :param choices: A list of ``Choice`` objects.

    Example::

        {
            "choices": [
                {
                    "message:"
                        {
                            "text": "The capital of France is Paris.",
                            "role": "assistant",
                        }
                },
            ]
        }
    """

    __autoclass_content__ = "class"

    choices: List[Choice] = []
    """A list of ``Choice`` objects."""


__all__ = ["Choice", "ResponseOutput"]
