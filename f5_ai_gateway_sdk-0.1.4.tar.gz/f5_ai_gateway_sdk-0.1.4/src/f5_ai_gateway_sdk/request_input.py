from enum import Enum
from io import StringIO
from typing import List

from pydantic import BaseModel


class MessageRole(str, Enum):
    """
    Enum for the fields that can be required in a processor signature.

    Available values:
        - ``USER``: Represents the user role in the conversation.
        - ``SYSTEM``: Represents the system role responsible for managing the conversation context.
        - ``ASSISTANT``: Represents the assistant role, typically used for responses from the AI.
        - ``TOOL``: Represents an external tool or resource invoked during the conversation.
    """

    USER = "user"
    SYSTEM = "system"
    ASSISTANT = "assistant"
    TOOL = "tool"


class Message(BaseModel):
    """
    Represents a message with a role and content.

    :param content: The text content of the message.
    :param role: The role of the message, which can be one of the values from MessageRole enum. Default is USER.
    """

    __autoclass_content__ = "class"

    content: str
    role: MessageRole = MessageRole.USER


class RequestInput(BaseModel):
    """
    Represents a collection of ``Message`` objects.

    :param messages: A list of ``Message`` objects representing the input messages.

    Example::

        {
            "messages": [
                {
                    "content": "What is the capital of France?",
                    "role": "user"
                },
                {
                    "content": "Only answer questions about geography",
                    "role": "system"
                }
            ]
        }
    """

    __autoclass_content__ = "class"
    messages: List[Message] = []

    def stream(self, roles: List[MessageRole] | None = None) -> StringIO:
        """
        Creates a stream of message contents, filtered by roles if provided.

        :meta private:

        :param roles: An optional list of roles to filter the messages by

        :return: A stream of concatenated message contents.
        """

        if roles is None:
            roles = []
        appender = StringIO()
        for message in self.messages:
            if roles and message.role not in roles:
                continue
            appender.write(message.content + "\n")
        return appender

    def concatenate(self, roles: List[MessageRole] | None = None) -> str:
        """
        Concatenates the message contents, filtered by roles if provided.

        :param roles: An optional list of roles to filter the messages by

        :return: A concatenated string of message contents.
        """
        return self.stream(roles).getvalue()


__all__ = ["Message", "RequestInput", "MessageRole"]
