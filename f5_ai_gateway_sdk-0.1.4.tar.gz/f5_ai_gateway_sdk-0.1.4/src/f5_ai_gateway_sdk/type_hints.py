from io import StringIO
from typing import (
    Optional,
    Union,
    TypeVar,
    IO,
    TypeAlias,
    MutableMapping,
    Mapping,
    List,
    Dict,
)

from f5_ai_gateway_sdk.request_input import RequestInput
from f5_ai_gateway_sdk.response_output import ResponseOutput


from .parameters import Parameters

JSONTypes = Union[
    str, int, float, bool, None, List["JSONTypes"], Dict[str, "JSONTypes"]
]
Metadata = dict[str, JSONTypes]
"""Metadata sent along to a processor to provide context for processing."""

JSON: TypeAlias = (
    Mapping[str, "JSON"] | MutableMapping[str, "JSON"] | list["JSON"] | JSONTypes
)
"""JSON-compatible data type."""

"""Metadata sent along to a processor to provide context for processing."""


StreamingPrompt = Optional[Union[IO[str], StringIO]]
"""Prompt text to be processed as a stream by a processor and later sent to a LLM."""


StreamingResponse = Optional[IO[str]]
"""Response text to streamed back to the client from a LLM."""

PROMPT = TypeVar(
    "PROMPT", bound=Union[RequestInput, StreamingPrompt], contravariant=True
)
"""Generic type variable for a prompt or streaming prompt."""

RESPONSE = TypeVar(
    "RESPONSE", bound=Union[ResponseOutput, StreamingResponse], contravariant=True
)
"""Generic type variable for a response or streaming response."""

PARAMS = TypeVar("PARAMS", bound=Parameters, contravariant=True)
"""Generic type variable for parameters sent to a processor."""


__all__ = [
    "JSON",
    "JSONTypes",
    "Metadata",
    "StreamingPrompt",
    "StreamingResponse",
    "PROMPT",
    "RESPONSE",
    "PARAMS",
]
