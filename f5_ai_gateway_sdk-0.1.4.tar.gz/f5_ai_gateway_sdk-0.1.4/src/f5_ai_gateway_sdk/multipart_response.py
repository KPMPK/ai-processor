import json

from typing import Tuple, Iterator, Optional

from starlette.responses import StreamingResponse as HttpStreamingResponse

from f5_ai_gateway_sdk.request_input import RequestInput
from f5_ai_gateway_sdk.response_output import ResponseOutput

from .multipart_fields import (
    INPUT_NAME,
    RESPONSE_NAME,
    METADATA_NAME,
    DEFAULT_ENCODING,
    generate_boundary,
    encode_multipart_field,
    HEADER_ENCODING,
)
from .type_hints import Metadata

MultipartFields = Tuple[RequestInput, ResponseOutput, Metadata]


class MultipartResponse(HttpStreamingResponse):
    """
    Response object that encodes a prompt and metadata as multipart/form-data.
    """

    BOUNDARY_SIZE = 64
    """Size of the boundary string in characters"""
    TEXT_CONTENT_TYPE = f"text/plain;charset={DEFAULT_ENCODING}"
    """Content type of the prompt/response body (typically prompt or prompt response)"""
    METADATA_CONTENT_TYPE = "application/json"
    """"Content type of the metadata for prompt or prompt response"""

    def __init__(
        self,
        metadata: Metadata,
        status_code: int,
        modified_prompt: Optional[RequestInput] = None,
        modified_response: Optional[ResponseOutput] = None,
    ):
        """
        Create a new MultipartResponse object.
        :param metadata: metadata for the prompt/response
        :param status_code: HTTP status code
        :param modified_prompt: prompt text to be processed by a processor and later sent to a LLM
        :param modified_response: response text to be sent back to the client from a LLM
        """
        if status_code < 1 or status_code > 599:
            raise ValueError("Invalid HTTP status code")
        if metadata is None:
            raise ValueError("Metadata is required")

        self.boundary = generate_boundary(self.BOUNDARY_SIZE)
        """Boundary string used to separate parts of the multipart/form-data response"""

        self.media_type = (
            f'multipart/form-data;charset={DEFAULT_ENCODING};boundary="{self.boundary}"'
        )
        """Media type of the response content that indicates the boundary string"""

        content = self.build_content(modified_prompt, modified_response, metadata)

        super().__init__(
            content=content,
            status_code=status_code,
            media_type=self.media_type,
            headers={"Content-Type": self.media_type},
        )

    @staticmethod
    def build_headers(field_name: str, content_type: str) -> list[dict[str, str]]:
        return [
            {"Content-Disposition": f'form-data; name="{field_name}"'},
            {"Content-Type": content_type},
        ]

    def build_content(
        self,
        prompt: Optional[RequestInput],
        response: Optional[ResponseOutput],
        metadata: Metadata,
    ) -> Iterator[bytes]:
        """
        Build the content of the multipart response by linking together the prompt, response, and
        metadata as byte streams.

        :param prompt: optional prompt
        :param response: optional response
        :param metadata: required metadata
        :return: byte iterator with the content of the multipart response
        """
        if metadata is None:
            raise ValueError("Metadata is required")

        if prompt:
            prompt_headers = MultipartResponse.build_headers(
                INPUT_NAME, self.TEXT_CONTENT_TYPE
            )
            prompt_json = prompt.model_dump_json()
            prompt_content = encode_multipart_field(
                self.boundary, prompt_headers, prompt_json
            )
            for chunk in prompt_content:
                yield chunk

        if response:
            response_headers = MultipartResponse.build_headers(
                RESPONSE_NAME, self.TEXT_CONTENT_TYPE
            )
            response_json = response.model_dump_json()
            response_content = encode_multipart_field(
                self.boundary, response_headers, response_json
            )
            for chunk in response_content:
                yield chunk

        json_metadata = json.dumps(metadata)
        metadata_headers = MultipartResponse.build_headers(
            METADATA_NAME, self.METADATA_CONTENT_TYPE
        )
        metadata_content = encode_multipart_field(
            self.boundary, metadata_headers, json_metadata
        )

        for chunk in metadata_content:
            yield chunk

        yield f"--{self.boundary}--\r\n".encode(HEADER_ENCODING)


__all__ = ["MultipartResponse", "MultipartFields"]
