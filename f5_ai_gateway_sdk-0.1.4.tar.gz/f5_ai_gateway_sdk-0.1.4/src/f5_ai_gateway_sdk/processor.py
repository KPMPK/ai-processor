import json
import logging
from abc import ABC, abstractmethod
from io import TextIOWrapper, StringIO
from json import JSONDecodeError
from typing import Generic, Optional, Type, Any, Callable, Union, Dict, Mapping, TypeVar

from pydantic import ValidationError
from pydantic_core import ErrorDetails
import python_multipart.multipart
from starlette.datastructures import FormData, UploadFile
from starlette.requests import Request
from starlette.responses import Response
from starlette.routing import Route
from starlette.status import (
    HTTP_200_OK,
    HTTP_400_BAD_REQUEST,
    HTTP_405_METHOD_NOT_ALLOWED,
    HTTP_404_NOT_FOUND,
    HTTP_501_NOT_IMPLEMENTED,
)

from opentelemetry import trace
from opentelemetry.semconv.trace import SpanAttributes

from .signature import Signature
from .multipart_fields import (
    INPUT_NAME,
    INPUT_PARAMETERS_NAME,
    RESPONSE_NAME,
    RESPONSE_PARAMETERS_NAME,
    METADATA_NAME,
    REQUIRED_MULTIPART_FIELDS,
    OPTIONAL_MULTIPART_FIELDS,
    DEFAULT_ENCODING,
    ALLOWED_ENCODINGS,
    HEADER_ENCODING,
)
from .errors import (
    ResponseObjectError,
    MissingMultipartFieldError,
    MetadataParseError,
    ProcessExecutionError,
    ProcessorError,
    UnexpectedContentTypeError,
    ParametersParseError,
    MissingPromptAndResponseError,
    MultipartParseError,
    PromptParseError,
    ResponseParseError,
    InvalidMultipartFields,
    InvalidEncoding,
)
from .request_input import RequestInput, Message
from .response_output import ResponseOutput, Choice
from .parameters import Parameters, EmptyParameters
from .result import Result, Tags
from .type_hints import (
    PROMPT,
    RESPONSE,
    Metadata,
    PARAMS,
    StreamingPrompt,
    StreamingResponse,
    JSONTypes,
)

tracer = trace.get_tracer("processor_sdk")

T = TypeVar("T")
Transformer = Callable[[Union[str, UploadFile]], T]


class Processor(ABC, Generic[PROMPT, RESPONSE, PARAMS]):
    """
    Base class for a processor. A processor is a route that processes
    a prompt and metadata and returns a result.
    """

    def __init__(
        self,
        name: str,
        version: str,
        namespace: str,
        signature: Signature,
        prompt_class: Type[PROMPT] = RequestInput,
        response_class: Type[RESPONSE] = ResponseOutput,
        parameters_class: Type[PARAMS] = EmptyParameters,
        app_details: Optional[Dict[str, JSONTypes]] = None,
    ):
        """
        Creates a new instance of a Processor.

        :param name: name of processor (used in API definition)
        :param version: version of processor (used in API definition)
        :param namespace: optional namespace used to identify a group of processors
        :param signature: used to validate incoming requests
        :param prompt_class: type for class that defines the prompt class for the processor
        :param response_class: type for class that defines the response class for the processor
        :param parameters_class: type for class that defines the config parameters for the processor
        :param app_details: optional dictionary of application details (e.g. version, description)

        Example::

            class ExampleProcessor(Processor):
                def __init__(self):
                    super().__init__(
                        name="example-processor",
                        version="v1",
                        namespace="tutorial",
                        signature = BOTH_SIGNATURE
                    )

        """
        if self.__contains_whitespace(name):
            raise ValueError("Processor name cannot contain whitespace")
        if self.__contains_whitespace(version):
            raise ValueError("Processor version cannot contain whitespace")
        if self.__contains_whitespace(namespace):
            raise ValueError("Processor namespace cannot contain whitespace")
        if parameters_class is not None and not issubclass(
            parameters_class, Parameters
        ):
            raise ValueError("parameters_class must be a subclass of Parameters")
        if signature is None:
            raise ValueError("Processor subclass must define signature")

        self.prompt_type = prompt_class
        """Type of the prompt content"""
        self.response_type = response_class
        """Type of the response content"""
        self.app_details = app_details
        """Runtime details of the application using the processor"""
        self.name = name
        """Name of the processor (without spaces)"""
        self.version = version
        """Version of the processor (independent of API version)"""
        self.namespace = namespace
        """Namespace of the processor (used to group processors)"""
        self.parameters_class = parameters_class
        """Class that defines the configuration parameters for the processor"""
        self.namespaced_path = f"{namespace.lower()}/{name.lower()}"
        """Namespaced path for the processor API"""
        self.path = f"/{{command:path}}/{self.namespaced_path}"
        """Path for the processor API that can be extended for subcommands"""
        self.methods = ["HEAD", "POST", "GET"]
        """Supported HTTP methods for the processor API"""
        self.signature = signature
        """Signature of the processor (used to verify requests)"""
        self.routes = [
            Route(
                path=self.path,
                methods=self.methods,
                name=self.name,
                endpoint=self.handle_request,
            ),
        ]
        self.span_attributes = {
            "processor_id": self.id(),
            "processor_version": self.version,
        }
        for key, value in (app_details or {}).items():
            self.span_attributes[f"app_{key}"] = str(value)

        """Starlette routes for the processor API"""

    def id(self) -> str:
        if self.namespace is not None:
            return f"{self.namespace}:{self.name}"
        else:
            return self.name

    def execute_path(self) -> str:
        return f"/execute/{self.namespaced_path}"

    def signature_path(self) -> str:
        return f"/signature/{self.namespaced_path}"

    def to_dict(self):
        return {
            "name": self.name,
            "version": self.version,
            "namespace": self.namespace or "",
            "id": self.id(),
            "path": self.execute_path(),
            "methods": sorted(list(self.methods)),
            "signature_path": self.signature_path(),
        }

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, Processor):
            return (
                self.name == other.name
                and self.version == other.version
                and self.namespace == other.namespace
            )
        else:
            return False

    @staticmethod
    def __contains_whitespace(test: str) -> bool:
        return any(char.isspace() for char in test)

    def choose_span(self, name: str):
        """
        This method chooses the current span to use for the processor. If the current span is not recording,
        then it will return the current span which means that we don't start a new span that starts recording
        when we don't want it to. If the current span is recording, then we start a new span which automatically
        becomes a sub-span of the current span.

        :param name: name of span
        :return: current non-recording span or a new span
        """
        current_span = trace.get_current_span()
        if not current_span.is_recording():
            span = current_span
        else:
            span = tracer.start_span(name=name, attributes=self.span_attributes)

        return span

    async def handle_request(self, request: Request) -> Response:
        """
        This method handles all requests from the Starlette route and handles
        any errors that may occur during the processor execution.

        :param request: HTTP request in the AI Gateway Processor format
        :return: HTTP response in the AI Gateway Processor format
        """

        # noinspection PyUnusedLocal
        response = Response(status_code=HTTP_501_NOT_IMPLEMENTED)

        with self.choose_span(name="handle_request") as span:
            content_length = request.headers.get("Content-Length")
            if content_length:
                span.set_attribute(
                    SpanAttributes.HTTP_REQUEST_CONTENT_LENGTH, content_length
                )
            transfer_encoding = request.headers.get("Transfer-Encoding")
            if transfer_encoding:
                span.set_attribute("http.request_transfer_encoding", transfer_encoding)

            if request.method == "HEAD":
                response = Response(
                    status_code=HTTP_200_OK,
                    headers={
                        "Content-Type": f"multipart/form-data;charset={DEFAULT_ENCODING}"
                    },
                )
            else:
                # We wrap the main processing logic in a try-except block to catch any errors,
                # so that we can return a proper HTTP response to the client.
                try:
                    response = await self._handle_command(request)
                except ProcessorError as e:
                    # Only log errors that are not client errors
                    if e.status_code > 499:
                        span.record_exception(e)
                        logging.log(logging.ERROR, "%s", e, exc_info=True)
                    # Propagate the error to the client with json error detail
                    response = Response(
                        status_code=e.status_code,
                        headers={"Content-Type": "application/json"},
                        content=e.json_error(),
                    )

            span.set_attribute(
                SpanAttributes.HTTP_RESPONSE_STATUS_CODE, response.status_code
            )

        return response

    async def _handle_command(self, request: Request) -> Response:
        """
        This method handles requests that are routed to a command sub-route of a processor.
        :param request: request to be treated as a command
        :return: a response object with the appropriate status code and content for the command or an error response
        """

        default_response = Response(
            status_code=HTTP_404_NOT_FOUND,
            headers={"Content-Type": "application/json"},
            content=self._response_content(
                status_code=HTTP_404_NOT_FOUND,
                message="Not found",
            ),
        )

        if "command" not in request.path_params:
            return default_response

        # If the request is a POST request and the command is "execute",
        # try to process and return the request
        if request.path_params["command"] == "execute":
            if request.method != "POST":
                return Response(
                    status_code=HTTP_405_METHOD_NOT_ALLOWED,
                    headers={"Content-Type": "application/json"},
                    content=self._response_content(
                        status_code=HTTP_405_METHOD_NOT_ALLOWED,
                        message="Only POST requests are supported",
                    ),
                )

            response = await self._parse_and_process(request)
            return response

        # If the request is a GET request and the command is "signature",
        # return a JSON blob representing the signature of the processor - that is
        # what types of inputs are valid for the processor.
        elif request.path_params["command"] == "signature":
            if request.method != "GET" and request.method != "POST":
                return Response(
                    status_code=HTTP_405_METHOD_NOT_ALLOWED,
                    headers={"Content-Type": "application/json"},
                    content=self._response_content(
                        status_code=HTTP_405_METHOD_NOT_ALLOWED,
                        message="Only GET requests are supported",
                    ),
                )

            content = {
                "fields": self.signature.to_list(),
                "parameters": self.parameters_class.model_json_schema(),
            }
            status_code = HTTP_200_OK
            if request.method == "POST":
                # If the request is a POST request, validate that the provided
                # parameters are valid for the parameters class that this
                # processor expects. AIGW will use this endpoint to verify
                # that configuration in aigw.yaml is valid for a processor.
                validation = {"valid": True, "errors": []}
                body = await request.body()
                try:
                    self.parameters_class.model_validate_json(
                        json_data=body, strict=True
                    )
                except ValidationError as err:
                    validation["errors"] = [
                        _error_details_to_str(e) for e in err.errors()
                    ]
                    validation["valid"] = False
                    status_code = HTTP_400_BAD_REQUEST
                content["validation"] = validation

            return Response(
                status_code=status_code,
                headers={"Content-Type": "application/json"},
                content=json.dumps(content),
            )

        return default_response

    @staticmethod
    def _extract_charset_encoding(
        content_type: Optional[str], fallback_encoding: str
    ) -> str:
        if not content_type:
            encoding = fallback_encoding
        else:
            _, params = python_multipart.multipart.parse_options_header(content_type)
            charset = params.get(b"charset")
            encoding = (
                charset.decode("us-ascii").lower() if charset else fallback_encoding
            )

        if encoding not in ALLOWED_ENCODINGS:
            raise InvalidEncoding(f"Unsupported text encoding: {encoding}")

        return encoding

    @staticmethod
    def _extract_multipart_field(
        form: FormData,
        field_name: str,
        error_class: Type[MultipartParseError],
        root_content_type_encoding: Optional[str] = None,
        transform_function: Optional[Transformer] = None,
    ) -> Any:
        try:
            field = form.get(field_name)
            if field is None:
                return None
            elif transform_function:
                transformed = transform_function(field)
            elif isinstance(field, UploadFile):
                # Use the encoding specified in the content type header if available
                # Otherwise, use the default encoding
                fallback_encoding = (
                    root_content_type_encoding
                    if root_content_type_encoding
                    else DEFAULT_ENCODING
                )
                encoding = Processor._extract_charset_encoding(
                    field.content_type, fallback_encoding
                )
                transformed = TextIOWrapper(field.file, encoding=encoding)
            else:
                transformed = field

            return transformed
        except (UnicodeDecodeError, UnicodeError) as e:
            raise MultipartParseError(
                detail=f"Unable to decode field [{field_name}]: {e}"
            ) from e
        except ValueError as e:
            raise error_class() from e

    @staticmethod
    def _field_to_str(field_name: str, field_body: Union[str, UploadFile]) -> str:
        """
        Loads a multipart field into a string, conditionally forking logic
        based on whether we were passed a string or an UploadFile object.

        :param field_name: name of the field being loaded
        :param field_body: object to be loaded into JSON
        :param object_hook: optional deserialization handler
        :return: json object
        """
        if isinstance(field_body, UploadFile):
            with field_body.file as reader:
                data = reader.read().decode()
        elif isinstance(field_body, str):
            data = field_body
        else:
            raise ValueError(f"field must be a string or UploadFile [{field_name}]")

        return data

    @staticmethod
    def _field_to_json(
        field_name: str, field_body: Union[str, UploadFile], object_hook=None
    ) -> Mapping[str, JSONTypes]:
        """
        Loads a multipart field into a JSON object, conditionally forking logic
        based on whether we were passed a string or an UploadFile object.

        :param field_name: name of the field being loaded
        :param field_body: object to be loaded into JSON
        :param object_hook: optional deserialization handler
        :return: json object
        """
        if isinstance(field_body, UploadFile):
            with field_body.file as reader:
                json_content = json.load(reader, object_hook=object_hook)
        elif isinstance(field_body, str):
            try:
                json_content = json.loads(field_body, object_hook=object_hook)
            except JSONDecodeError as e:
                raise MultipartParseError(
                    detail=f"Unable to parse JSON field [{field_name}]: {e}"
                ) from e
        else:
            raise ValueError("field must be a string or UploadFile")

        return json_content

    def _parameters_transform(self, field_body: Union[str, UploadFile]) -> Parameters:
        span = trace.get_current_span()
        if field_body is None:
            span.set_attribute("parameters", "None")
            parameters = self.parameters_class()
        else:
            json_str = self._field_to_str(
                field_name="parameters",
                field_body=field_body,
            )
            try:
                parameters = self.parameters_class.model_validate_json(
                    json_data=json_str, strict=True
                )
                if span.is_recording():
                    for key, attribute in parameters.otel_attributes():
                        span.set_attribute(key, attribute)
            except TypeError as e:
                raise ParametersParseError() from e

        return parameters

    def _metadata_transform(self, field_body: Union[str, UploadFile]) -> Metadata:
        span = trace.get_current_span()

        if field_body is None:
            metadata = Metadata()
        else:
            json_content = self._field_to_json(
                field_name=METADATA_NAME, field_body=field_body
            )
            if not isinstance(json_content, dict):
                raise MetadataParseError(detail="metadata must be a JSON object")
            metadata = Metadata(**json_content)

        if span.is_recording():
            for key, value in metadata.items():
                if isinstance(value, (str, int, float, bool)):
                    span.set_attribute(f"metadata.{key}", value)
                else:
                    span.set_attribute(f"metadata.{key}", json.dumps(value))

        return metadata

    def _input_transform(self, field_body: Union[str, UploadFile]) -> RequestInput:
        if field_body is None:
            prompt = RequestInput()
        else:
            prompt = self._field_to_json(
                field_name=INPUT_NAME,
                field_body=field_body,
            )
            prompt = RequestInput.model_validate(prompt)
            if not isinstance(prompt, RequestInput):
                raise MetadataParseError(detail="input.messages must be a JSON object")
        return prompt

    def _response_transform(self, field_body: Union[str, UploadFile]) -> ResponseOutput:
        if field_body is None:
            response = ResponseOutput()
        else:
            response = self._field_to_json(
                field_name=RESPONSE_NAME,
                field_body=field_body,
            )
            response = ResponseOutput.model_validate(response)
            if not isinstance(response, ResponseOutput):
                raise MetadataParseError(
                    detail="response.choices must be a JSON object"
                )
        return response

    def _validate_and_find_parameters_name(self, form: FormData) -> Optional[str]:
        """
        Validates the multipart form fields and returns the name of the parameters field if present.

        :param form: form containing fields
        :return: parameters field name if found, otherwise None
        :raises MissingMultipartFieldError: if a required field is missing
        :raises MissingPromptAndResponseError: if both prompt and response are missing
        :raises InvalidMultipartFields: if both prompt and response parameters are present
        """
        matched_input = False
        matched_response = False
        matched_input_parameters = False
        matched_response_parameters = False

        for required in REQUIRED_MULTIPART_FIELDS:
            if required not in form:
                raise MissingMultipartFieldError(field_name=required)

        # Modify the default values of the fields to True if they are present in the form
        for field in form:
            if field == INPUT_NAME:
                matched_input = True
            if field == RESPONSE_NAME:
                matched_response = True
            if field == INPUT_PARAMETERS_NAME:
                matched_input_parameters = True
            if field == RESPONSE_PARAMETERS_NAME:
                matched_response_parameters = True

        # We are processing a prompt response ONLY if it contains the RESPONSE_NAME field.
        # Otherwise, implicitly it is a prompt request.
        is_response_request = matched_response
        is_prompt_request = not is_response_request

        # Validate that either a prompt or a prompt response has been submitted
        if not matched_input and not matched_response:
            raise MissingPromptAndResponseError()

        if is_response_request:
            if not self.signature.supports_response:
                raise InvalidMultipartFields(
                    "Processor signature does not allow response fields"
                )

            if self.signature.required is not None:
                for required in map(lambda f: f.value, self.signature.required):
                    if required not in form:
                        raise InvalidMultipartFields(
                            f"Missing required field for response: {required}"
                        )

        if is_prompt_request:
            if not self.signature.supports_input:
                raise InvalidMultipartFields(
                    "Processor signature does not allow input fields"
                )

            if self.signature.required is not None:
                for required in map(lambda f: f.value, self.signature.required):
                    if required not in form:
                        raise InvalidMultipartFields(
                            f"Missing required field for input: {required}"
                        )

        # Validate that the correct parameters are being used
        if is_response_request and matched_input_parameters:
            raise InvalidMultipartFields(
                f"prompt parameters cannot be present with {RESPONSE_NAME} field"
            )
        if is_prompt_request and matched_response_parameters:
            raise InvalidMultipartFields(
                f"response parameters cannot be present with only a {INPUT_NAME} field"
            )

        # Choose the right parameters field based on the request type
        if matched_input_parameters:
            return INPUT_PARAMETERS_NAME
        elif matched_response_parameters:
            return RESPONSE_PARAMETERS_NAME
        else:
            return None

    @staticmethod
    async def _parse_and_validate_content_type_header(
        request: Request,
    ) -> tuple[bytes, dict[bytes, bytes]]:
        """
        Validates the headers of the incoming request to ensure that the
        Content-Type header is present, that it is a multipart/form-data,
        and that it contains a boundary parameter.
        :param request: request to read headers from
        :raises MultipartRequestError: if the headers are invalid"""

        raw_request_content_type = request.headers.get("Content-Type")
        if raw_request_content_type is None:
            raise UnexpectedContentTypeError(detail="Content-Type header missing")
        content_type, params = python_multipart.multipart.parse_options_header(
            raw_request_content_type
        )
        if not content_type or len(content_type) == 0:
            raise UnexpectedContentTypeError(detail="Content-Type header is empty")
        if content_type != b"multipart/form-data":
            raise UnexpectedContentTypeError(
                detail="Content-Type header mismatch - expecting: multipart/form-data"
            )
        if params.get(b"boundary") is None:
            raise UnexpectedContentTypeError(
                detail="Content-Type header missing boundary"
            )

        return content_type, params

    @staticmethod
    def _response_content(
        status_code: int,
        message: str,
    ) -> str:
        return json.dumps(
            {
                "message": message,
                "status_code": status_code,
            }
        )

    async def _parse_multipart_fields(
        self, root_content_type_encoding: str, form: FormData
    ) -> tuple:
        """
        Extract each expected multipart field from the form and transform it using predefined
        functions. Then, the prompt and response are converted to the appropriate type based on
        the processor's prompt_type and response_type. If there is no need for conversion,
        they are left as-is.

        :param root_content_type_encoding: character set encoding specified for the HTTP request (not multipart field)
        :param form: multipart form field to parse
        :return: tuple of metadata, parameters, prompt, and response
        """

        span = trace.get_current_span()
        span.set_attribute("multipart.fields", ", ".join(form.keys()))

        parameters_field = self._validate_and_find_parameters_name(form)
        # PARAMETERS
        if parameters_field:
            parameters = Processor._extract_multipart_field(
                form=form,
                field_name=parameters_field,
                error_class=ParametersParseError,
                transform_function=self._parameters_transform,
            )
        else:
            try:
                parameters = self.parameters_class()
            except Exception as e:
                raise ProcessExecutionError() from e

        # METADATA
        metadata = Processor._extract_multipart_field(
            form=form,
            field_name=METADATA_NAME,
            error_class=MetadataParseError,
            transform_function=self._metadata_transform,
        )
        # INPUT
        prompt = Processor._extract_multipart_field(
            form=form,
            field_name=INPUT_NAME,
            root_content_type_encoding=root_content_type_encoding,
            transform_function=self._input_transform,
            error_class=PromptParseError,
        )
        # RESPONSE
        response = Processor._extract_multipart_field(
            form=form,
            field_name=RESPONSE_NAME,
            root_content_type_encoding=root_content_type_encoding,
            transform_function=self._response_transform,
            error_class=ResponseParseError,
        )

        # This logic is to handle the conversion of the prompt and response fields to the appropriate type.
        # When a multipart field is received and contains a `filename` parameter in the Content-Disposition
        # header, Starlette will return an UploadFile object. This means that depending on the parameters
        # set in Content-Disposition, the field could be either a subclass of IO or a string.
        #
        # Unfortunately, there is a conflict between this behavior and the behavior possible in a subclass of
        # Processor. The prompt and response fields are expected to be of the type defined by the processor's
        # prompt_type and response_type (matching the generic type definition). As such, we may end up in a
        # situation where we need to convert a string to an IO object or vice versa.
        #
        # Ultimately, a comprehensive fix will involve a PR to Starlette or us no longer using the integrated
        # Starlette multipart form parsing. For now, we will handle the conversion here. Please note that despite
        # a prompt or response having a type of StreamingPrompt or StreamingResponse, the field may still
        # end up being loaded into memory before it is converted into a IO object.
        if self.prompt_type == StreamingPrompt and isinstance(prompt, str):
            prompt = StringIO(prompt)
        elif self.prompt_type == RequestInput and isinstance(prompt, TextIOWrapper):
            with prompt as reader:
                text = reader.read()
            prompt = RequestInput(messages=[Message(content=text)])
        if self.response_type == StreamingResponse and isinstance(response, str):
            response = StringIO(response)
        elif self.response_type == ResponseOutput and isinstance(
            response, TextIOWrapper
        ):
            with response as reader:
                text = reader.read()
            response = ResponseOutput(choices=[Choice(message=Message(content=text))])

        return metadata, parameters, prompt, response

    @tracer.start_as_current_span("parse_and_process")
    async def _parse_and_process(self, request: Request) -> Response:
        """
        This method executes the processor for the received request and will
        raise errors that inherit from ProcessorError.

        :param request: HTTP request in the AI Gateway Processor format
        :return: HTTP response in the AI Gateway Processor format
        """

        (
            _,
            content_type_params,
        ) = await Processor._parse_and_validate_content_type_header(request)
        charset = content_type_params.get(b"charset")
        root_content_type_encoding = (
            charset.decode(HEADER_ENCODING).lower() if charset else DEFAULT_ENCODING
        )
        max_fields = len(REQUIRED_MULTIPART_FIELDS) + len(OPTIONAL_MULTIPART_FIELDS)

        async with request.form(max_fields=max_fields, max_files=max_fields) as form:
            processed_fields = await self._parse_multipart_fields(
                root_content_type_encoding=root_content_type_encoding, form=form
            )
            metadata, parameters, prompt, response = processed_fields

            if metadata is None:
                raise MissingMultipartFieldError(field_name=METADATA_NAME)

            # This must be under the async block otherwise the IO streams will be closed
            with tracer.start_span(name="process") as span:
                try:
                    result = self.process(
                        metadata=metadata,
                        parameters=parameters,
                        prompt=prompt,
                        response=response,
                        request=request,
                    )

                    if result:
                        attributes = {
                            "rejected": result.rejected,
                            "modified": result.modified,
                            "processor_result": json.dumps(result.processor_result),
                            "tags": str(result.tags),
                        }
                        if result.processor_result:
                            attributes["processor_result"] = json.dumps(
                                result.processor_result
                            )
                        if result.metadata:
                            attributes["metadata"] = json.dumps(result.metadata)
                        if result.tags:
                            attributes["tags"] = str(result.tags)

                        span.add_event(name="result", attributes=attributes)

                        # Handle processor modifying the prompt in a response stage
                        if response is not None and result.prompt:
                            logging.log(
                                logging.WARNING,
                                "modified prompt detected in response stage, this modification will be dropped",
                            )
                            result.prompt = None

                except Exception as e:
                    raise ProcessExecutionError() from e

        if result is None:
            raise ProcessExecutionError(
                detail=f"Processor[{self.id()}] process() method returned None"
            )

        try:
            result.metadata["processor_id"] = self.id()
            result.metadata["processor_version"] = self.version

            if self.app_details is not None:
                result.metadata["app_details"] = self.app_details

            return result.to_response()
        except Exception as e:
            raise ResponseObjectError() from e

    @abstractmethod
    def process(
        self,
        prompt: Optional[PROMPT],
        response: Optional[RESPONSE],
        metadata: Metadata,
        parameters: PARAMS,
        request: Request,
    ) -> Result:
        """
        This abstract method is for implementors of the processor to define
        with their own custom logic. Errors should be raised as a subclass
        of ProcessorError. The return value should be a Result object.

        :param prompt: Optional prompt content to be evaluated
        :param response: Optional response content to be evaluated
        :param metadata: Prompt/Response metadata
        :param parameters: Processor parameters - configuration sent by gateway
        :param request: Original HTTP request
        :return: Result object indicating if the request was rejected, accepted, or modified

        Example::

            def process(self, prompt, response, metadata, parameters, request):
                target_found = False
                target_str = "target"

                if response:
                    target_found = any(
                        target_str in choice.message.content for choice in response.choices
                    )
                elif prompt:
                    target_found = any(target_str in message.content for message in prompt.messages)

                result = Metadata({"target_found": target_found})

                return Result(processor_result=result)
        """


def _error_details_to_str(err: ErrorDetails) -> str:
    """
    Returns a string summary of a pydantic ErrorDetails object.

    :param err: ErrorDetails object to summarize
    :return: String summary of the error
    """
    message = err["msg"] if "msg" in err else "unknown error"
    if "msg" not in err:
        logging.log(logging.WARNING, "no details found in error: %s", err)
    if "loc" in err and len(err["loc"]) > 0:
        loc_strings = [str(loc) for loc in err["loc"]]
        message = f"{message}: {','.join(loc_strings)}"
    return message


__all__ = ["Processor", "Result", "Tags"]
