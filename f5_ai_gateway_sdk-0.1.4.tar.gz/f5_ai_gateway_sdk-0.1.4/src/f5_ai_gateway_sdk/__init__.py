"""Processor SDK for F5 AI Gateway"""

# F403 - deals with ruff's detection of underpinning objects beneath '*' to determine whether they are used here or not
from .errors import *  # noqa: F403
from .processor import *  # noqa: F403
from .processor_routes import *  # noqa: F403
from .result import *  # noqa: F403
from .signature import *  # noqa: F403
from .parameters import *  # noqa: F403
from .request_input import *  # noqa: F403
from .response_output import *  # noqa: F403
from . import multipart_fields
from . import multipart_response
from . import type_hints
from . import Tags


# F405 - deals with non-explicitly defined variables within the namespace that are imported via '*'
__all__ = [
    "ALL_PREDEFINED_SIGNATURES",  # noqa: F405
    "BOTH_RESPONSE_PROMPT_SIGNATURE",  # noqa: F405
    "BOTH_SIGNATURE",  # noqa: F405
    "INPUT_ONLY_SIGNATURE",  # noqa: F405
    "Choice",  # noqa: F405
    "ProcessExecutionError",  # noqa: F405
    "Processor",  # noqa: F405
    "ProcessorError",  # noqa: F405
    "ProcessorRoutes",  # noqa: F405
    "RESPONSE_AND_PROMPT_SIGNATURE",  # noqa: F405
    "RESPONSE_ONLY_SIGNATURE",  # noqa: F405
    "Result",  # noqa: F405
    "RequestInput",  # noqa: F405
    "ResponseOutput",  # noqa: F405
    "Signature",  # noqa: F405
    "SignatureField",  # noqa: F405
    "Message",  # noqa: F405
    "MessageRole",  # noqa: F405
    "multipart_fields",
    "multipart_response",  # noqa: F405
    "parameters",  # noqa: F405
    "signature",  # noqa: F405
    "type_hints",
    "Tags",  # noqa: F405
]
